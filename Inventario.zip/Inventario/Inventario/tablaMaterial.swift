//
//  tablaMaterial.swift
//  Inventario
//
//  Created by Fernando Pedraza Ledezma on 6/9/19.
//  Copyright © 2019 Fernando Pedraza Ledezma. All rights reserved.
//

import UIKit
import Firebase

class tablaMaterial: UITableViewController, UISearchBarDelegate {

    var couches: [Couche] = []
    var backUpcouches: [Couche] = []
    
    var ref: DocumentReference!
    var getRef: Firestore!
    
    
    @IBOutlet weak var buscador: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getRef = Firestore.firestore()
        buscador.delegate = self as! UISearchBarDelegate
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getAlumnos()
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return couches.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda2", for: indexPath)
        
        let Couche = couches[indexPath.row]
        
        cell.textLabel!.text = "Couche" //fire
        cell.detailTextLabel?.text = Couche.Medida //fire
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let delete = UITableViewRowAction(style: .destructive, title: "Borrar") { (action, indexPath) in
            let Couche: Couche!
            Couche = self.couches[indexPath.row]
            self.getRef.collection("Couche").document(Couche.id!).delete()
        }
        
        return [delete]
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        guard !searchText.isEmpty else{
            couches = backUpcouches
            DispatchQueue.main.async{
                self.tableView.reloadData()
            }
            return
        }
        
        couches = backUpcouches.filter({ (Couche) -> Bool in
            (Couche.Medida?.lowercased().contains(searchText.lowercased()))!
        })
        
        DispatchQueue.main.async{
            self.tableView.reloadData()
        }
    }
    
    
    func getAlumnos(){
        //getRef.collection("alumno").getDocuments { (querySnapshot, error) in
        
        getRef.collection("Couche").addSnapshotListener { (querySnapshot, error) in
            if let error = error{
                print(error.localizedDescription)
            }else{
                self.couches.removeAll()
                for document in querySnapshot!.documents{
                    let id = document.documentID
                    let values = document.data()
                    let medida = values["Medida"] as? String ?? "sin medida"
                    let couche = Couche(id: id, Medida: medida)
                    self.couches.append(couche)
                }
                self.backUpcouches = self.couches
                self.tableView.reloadData()
            }
        }
    }
    
    
    @IBAction func fueraMatTabla(_ sender: Any) {
        dismiss(animated: true, completion: nil)

    }
    
    
    
}
