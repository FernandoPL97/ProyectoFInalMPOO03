//
//  inicioView.swift
//  Inventario
//
//  Created by Fernando Pedraza Ledezma on 6/9/19.
//  Copyright © 2019 Fernando Pedraza Ledezma. All rights reserved.
//

import UIKit
import Firebase

class inicioSesion: UIViewController {

    
    @IBOutlet weak var correo: UITextField!
    @IBOutlet weak var contraseña: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        correo.becomeFirstResponder()
        isLogged()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        isLogged()
    }
    
    
    @IBAction func entrarSesion(_ sender: UIButton) {
        guard let userEmail = correo.text,userEmail != "", let userPass = contraseña.text, userPass != "" else {
            //clouserh de aviso AAAAAAAAAAAAAAAAAAAAAAAAAAA
            return
        }
        
        Auth.auth().signIn(withEmail: userEmail, password: userPass) { (user, error) in
            if let error = error{
                print(error.localizedDescription)
                return
            }
        }
    }
    
    func isLogged(){
        Auth.auth().addStateDidChangeListener { (auth, user) in
            if user == nil{
                print("No esta loggeado")
            }else{
                print("Si esta loggeado")
                self.performSegue(withIdentifier: "menuPrincipal", sender: self)
            }
        }
    }
        
        
        
}

