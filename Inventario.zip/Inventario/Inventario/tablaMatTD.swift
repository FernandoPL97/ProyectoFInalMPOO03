//
//  tablaMatTD.swift
//  Inventario
//
//  Created by Fernando Pedraza Ledezma on 6/14/19.
//  Copyright © 2019 Fernando Pedraza Ledezma. All rights reserved.
//

import UIKit
import Firebase

class tablaMatTDirecto: UITableViewController, UISearchBarDelegate {
    
    var tdirectos: [TDirecto] = []
    var backUptdirectos: [TDirecto] = []
    
    var ref: DocumentReference!
    var getRef: Firestore!
    
    
    
    @IBOutlet weak var busTD: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getRef = Firestore.firestore()
        busTD.delegate = self as! UISearchBarDelegate
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getAlumnos()
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tdirectos.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda6", for: indexPath)
        
        let TDirecto = tdirectos[indexPath.row]
        
        cell.textLabel!.text = "TDirecto" //fire
        cell.detailTextLabel?.text = TDirecto.Medida //fire
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let delete = UITableViewRowAction(style: .destructive, title: "Borrar") { (action, indexPath) in
            let TDirecto: TDirecto!
            TDirecto = self.tdirectos[indexPath.row]
            self.getRef.collection("TDirecto").document(TDirecto.id!).delete()
        }
        
        return [delete]
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        guard !searchText.isEmpty else{
            tdirectos = backUptdirectos
            DispatchQueue.main.async{
                self.tableView.reloadData()
            }
            return
        }
        
        tdirectos = backUptdirectos.filter({ (TDirecto) -> Bool in
            (TDirecto.Medida?.lowercased().contains(searchText.lowercased()))!
        })
        
        DispatchQueue.main.async{
            self.tableView.reloadData()
        }
    }
    
    
    func getAlumnos(){
        //getRef.collection("alumno").getDocuments { (querySnapshot, error) in
        
        getRef.collection("TDirecto").addSnapshotListener { (querySnapshot, error) in
            if let error = error{
                print(error.localizedDescription)
            }else{
                self.tdirectos.removeAll()
                for document in querySnapshot!.documents{
                    let id = document.documentID
                    let values = document.data()
                    let medida = values["Medida"] as? String ?? "sin medida"
                    let tdirecto = TDirecto(id: id, Medida: medida)
                    self.tdirectos.append(tdirecto)
                }
                self.backUptdirectos = self.tdirectos
                self.tableView.reloadData()
            }
        }
    }
    
    
    @IBAction func fueraTD(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    

}

