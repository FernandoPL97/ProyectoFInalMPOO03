//
//  tablaMatPPT.swift
//  Inventario
//
//  Created by Fernando Pedraza Ledezma on 6/14/19.
//  Copyright © 2019 Fernando Pedraza Ledezma. All rights reserved.
//

import UIKit
import Firebase

class tablaMatPPT: UITableViewController, UISearchBarDelegate {
    
    var PPTransparentes: [PPTransparente] = []
    var backUpPPTransparentes: [PPTransparente] = []
    
    var ref: DocumentReference!
    var getRef: Firestore!
    
    @IBOutlet weak var busPPT: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getRef = Firestore.firestore()
        busPPT.delegate = self as! UISearchBarDelegate
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getAlumnos()
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return PPTransparentes.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda4", for: indexPath)
        
        let PPTransparente = PPTransparentes[indexPath.row]
        
        cell.textLabel!.text = "PPTransparente" //fire
        cell.detailTextLabel?.text = PPTransparente.Medida //fire
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let delete = UITableViewRowAction(style: .destructive, title: "Borrar") { (action, indexPath) in
            let PPTransparente: PPTransparente!
            PPTransparente = self.PPTransparentes[indexPath.row]
            self.getRef.collection("PPTransparente").document(PPTransparente.id!).delete()
        }
        
        return [delete]
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        guard !searchText.isEmpty else{
            PPTransparentes = backUpPPTransparentes
            DispatchQueue.main.async{
                self.tableView.reloadData()
            }
            return
        }
        
        PPTransparentes = backUpPPTransparentes.filter({ (PPTransparente) -> Bool in
            (PPTransparente.Medida?.lowercased().contains(searchText.lowercased()))!
        })
        
        DispatchQueue.main.async{
            self.tableView.reloadData()
        }
    }
    
    
    func getAlumnos(){
        //getRef.collection("alumno").getDocuments { (querySnapshot, error) in
        
        getRef.collection("PPTransparente").addSnapshotListener { (querySnapshot, error) in
            if let error = error{
                print(error.localizedDescription)
            }else{
                self.PPTransparentes.removeAll()
                for document in querySnapshot!.documents{
                    let id = document.documentID
                    let values = document.data()
                    let medida = values["Medida"] as? String ?? "sin medida"
                    let pptransparente = PPTransparente(id: id, Medida: medida)
                    self.PPTransparentes.append(pptransparente)
                }
                self.backUpPPTransparentes = self.PPTransparentes
                self.tableView.reloadData()
            }
        }
    }
    
    

    @IBAction func fueraPPT(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
}


