//
//  tablaTrT.swift
//  Inventario
//
//  Created by Fernando Pedraza Ledezma on 6/14/19.
//  Copyright © 2019 Fernando Pedraza Ledezma. All rights reserved.
//

import UIKit
import Firebase

class tablaMatTrT: UITableViewController, UISearchBarDelegate {
    
    var Trts: [TrT] = []
    var backUpTrts: [TrT] = []
    
    var ref: DocumentReference!
    var getRef: Firestore!
    
    
    @IBOutlet weak var busTrt: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getRef = Firestore.firestore()
        busTrt.delegate = self as! UISearchBarDelegate
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getAlumnos()
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Trts.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda8", for: indexPath)
        
        let Trt = Trts[indexPath.row]
        
        cell.textLabel!.text = "TT" //fire
        cell.detailTextLabel?.text = Trt.Medida //fire
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let delete = UITableViewRowAction(style: .destructive, title: "Borrar") { (action, indexPath) in
            let Trt: TrT!
            Trt = self.Trts[indexPath.row]
            self.getRef.collection("Trt").document(Trt.id!).delete()
        }
        
        return [delete]
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        guard !searchText.isEmpty else{
            Trts = backUpTrts
            DispatchQueue.main.async{
                self.tableView.reloadData()
            }
            return
        }
        
        Trts = backUpTrts.filter({ (Trt) -> Bool in
            (Trt.Medida?.lowercased().contains(searchText.lowercased()))!
        })
        
        DispatchQueue.main.async{
            self.tableView.reloadData()
        }
    }
    
    
    func getAlumnos(){
        //getRef.collection("alumno").getDocuments { (querySnapshot, error) in
        
        getRef.collection("Trt").addSnapshotListener { (querySnapshot, error) in
            if let error = error{
                print(error.localizedDescription)
            }else{
                self.Trts.removeAll()
                for document in querySnapshot!.documents{
                    let id = document.documentID
                    let values = document.data()
                    let medida = values["Medida"] as? String ?? "sin medida"
                    let trt = TrT(id: id, Medida: medida)
                    self.Trts.append(trt)
                }
                self.backUpTrts = self.Trts
                self.tableView.reloadData()
            }
        }
    }
    
    
    
    
    @IBAction func fueraTrT(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
    
    
}

