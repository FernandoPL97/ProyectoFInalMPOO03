//
//  seleccionM.swift
//  Inventario
//
//  Created by Fernando Pedraza Ledezma on 6/10/19.
//  Copyright © 2019 Fernando Pedraza Ledezma. All rights reserved.
//

import UIKit

class seleccionM: UIViewController{
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    @IBAction func coucheSelec(_ sender: UIButton) {
        self.performSegue(withIdentifier: "tablase", sender: self)
    }
    
    @IBAction func TTSelec(_ sender: UIButton) {
        self.performSegue(withIdentifier: "tablaTrT", sender: self)
    }
    
    
    @IBAction func PPTSelec(_ sender: UIButton) {
        self.performSegue(withIdentifier: "tablaPPT", sender: self)
    }
    
    
    @IBAction func PPBSelec(_ sender: UIButton){
        self.performSegue(withIdentifier: "tablaPPB", sender: self)
    }


    @IBAction func TDSelec(_ sender: UIButton) {
        self.performSegue(withIdentifier: "tablaTDirecto", sender: self)
    }
    
    
    @IBAction func RadianteSlec(_ sender: UIButton) {
        self.performSegue(withIdentifier: "tablaRadiante", sender: self)
    }
    
    
    
    @IBAction func fueraInve(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
}
