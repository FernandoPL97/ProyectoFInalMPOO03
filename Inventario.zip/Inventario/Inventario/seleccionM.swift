//
//  seleccionM.swift
//  Inventario
//
//  Created by Fernando Pedraza Ledezma on 6/10/19.
//  Copyright © 2019 Fernando Pedraza Ledezma. All rights reserved.
//

import UIKit

class seleccionM: UIViewController{
    
    var selecmat : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
    @IBOutlet weak var mateSelec: UILabel!
    
    
    @IBAction func coucheSelec(_ sender: UIButton) {
        mateSelec.text = "Couche"
        selecmat = "Couche"
    }
    
    @IBAction func TTSelec(_ sender: UIButton) {
        mateSelec.text = "TrT"
        selecmat = "TrT"
    }
    
    
    @IBAction func PPTSelec(_ sender: UIButton) {
        mateSelec.text = "PPTransparente"
        selecmat = "PPTransparente"
    }
    
    
    @IBAction func PPBSelec(_ sender: UIButton){
       mateSelec.text = "PPBlanco"
        selecmat = "PPBlanco"
    }


    @IBAction func TDSelec(_ sender: UIButton) {
        mateSelec.text = "TDirecto"
        selecmat = "TDirecto"
    }
    
    
    @IBAction func RadianteSlec(_ sender: UIButton) {
        mateSelec.text = "Radiante"
        selecmat = "Radiante"
    }
    
    
    
    @IBAction func SelecMatB(_ sender: UIButton) {
        
        self.performSegue(withIdentifier: "tablase", sender: self)
        //print(selecmat, "seleccion")
        
    }
    
    
    @IBAction func fueraInve(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
}
