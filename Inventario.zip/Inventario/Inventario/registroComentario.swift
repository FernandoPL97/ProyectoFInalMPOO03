//
//  registroComentario.swift
//  Inventario
//
//  Created by Fernando Pedraza Ledezma on 6/10/19.
//  Copyright © 2019 Fernando Pedraza Ledezma. All rights reserved.
//

import UIKit
import Firebase

class registroComentario: UIViewController {
    
    var ref: DocumentReference!
    var getRef: Firestore!
    
    @IBOutlet weak var matID: UITextField!
    @IBOutlet weak var matCom: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        matID.becomeFirstResponder()
        getRef = Firestore.firestore()
    }
    
    
    
    @IBAction func agregarComen(_ sender: UIButton) {
        var datos: [String: Any] = ["nombre": matID.text, "apellido": matCom.text]
        
        
        
        ref = getRef.collection("alumno").addDocument(data: datos, completion: { (error) in
            if let error = error {
                print(error.localizedDescription)
            }else{
                print("Se guardo exitosamente el Comentario")
                self.dismiss(animated: true, completion: nil)
            }
        })
    }
    
    
    
    @IBAction func fueraregiscomen(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
}
