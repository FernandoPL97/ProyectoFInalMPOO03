//
//  menuPrincipal.swift
//  Inventario
//
//  Created by Fernando Pedraza Ledezma on 6/9/19.
//  Copyright © 2019 Fernando Pedraza Ledezma. All rights reserved.
//

import UIKit
import Firebase

class menuPrincipal: UIViewController {
    
    @IBOutlet weak var correoUsuario: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        correoUsuario.text =  Auth.auth().currentUser?.email
    }
    
    
    
    @IBAction func cerrarSesion(_ sender: UIButton) {
        do{
            try Auth.auth().signOut()
            dismiss(animated: true, completion: nil)
        }catch let error{
            print(error.localizedDescription)
        }
    }
    
    


}
