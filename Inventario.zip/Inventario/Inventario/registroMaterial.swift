//
//  registroMaterial.swift
//  Inventario
//
//  Created by Fernando Pedraza Ledezma on 6/9/19.
//  Copyright © 2019 Fernando Pedraza Ledezma. All rights reserved.
//

import UIKit
import Firebase


class agregarMaterial: UIViewController{
    
    
    var ref: DocumentReference!
    var getRef: Firestore!
    
    @IBOutlet weak var medidaM: UITextField!
    @IBOutlet weak var Materialt: UILabel!
    
    
    @IBAction func Couchelabel(_ sender: UIButton) {
        Materialt.text = "Couche"
    }
    
    @IBAction func TTlabel(_ sender: UIButton) {
        Materialt.text = "TrT"
    }
    
    @IBAction func PPTlabel(_ sender: UIButton) {
        Materialt.text = "PPTransparente"
    }
    
    @IBAction func PPBlabel(_ sender: UIButton) {
        Materialt.text = "PPBlanco"
    }
    
    @IBAction func TDlabel(_ sender: UIButton) {
        Materialt.text = "TDirecto"
    }
    
    
    @IBAction func Radiantelsbel(_ sender: UIButton) {
        Materialt.text = "Radiante"
    }
    
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        medidaM.becomeFirstResponder()
        getRef = Firestore.firestore()
        
    }
    
    
    
    @IBAction func agregarMaterial(_ sender: UIButton) {

        var datos: [String: Any] = ["Medida": medidaM.text]
        
        
        
        ref = getRef.collection(Materialt.text!).addDocument(data: datos, completion: { (error) in
            if let error = error {
                print(error.localizedDescription)
           }else{
                print("Se guardaron exitosamente los datos")
                self.dismiss(animated: true, completion: nil)
            }
        })
        
        
    }
    
    
    
    @IBAction func fueraRegisMat(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
    
    
}

