//
//  PPBlanco.swift
//  Inventario
//
//  Created by Fernando Pedraza Ledezma on 6/9/19.
//  Copyright © 2019 Fernando Pedraza Ledezma. All rights reserved.
//

import UIKit

class PPBlanco{
    
    var id: String?
    var Medida: String?
    
    
    init(id: String, Medida: String){
        self.id = id
        self.Medida = Medida
    }
    
    
}
