//
//  tablaMatRad.swift
//  Inventario
//
//  Created by Fernando Pedraza Ledezma on 6/14/19.
//  Copyright © 2019 Fernando Pedraza Ledezma. All rights reserved.
//

import UIKit
import Firebase

class tablaMatRadiante: UITableViewController, UISearchBarDelegate {
    
    var radiantes: [Radiante] = []
    var backUpradiantes: [Radiante] = []
    
    var ref: DocumentReference!
    var getRef: Firestore!
    
    
    @IBOutlet weak var busRad: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getRef = Firestore.firestore()
        busRad.delegate = self as! UISearchBarDelegate
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getAlumnos()
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return radiantes.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda7", for: indexPath)
        
        let Radiante = radiantes[indexPath.row]
        
        cell.textLabel!.text = "Radiante" //fire
        cell.detailTextLabel?.text = Radiante.Medida //fire
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let delete = UITableViewRowAction(style: .destructive, title: "Borrar") { (action, indexPath) in
            let Radiante: Radiante!
            Radiante = self.radiantes[indexPath.row]
            self.getRef.collection("Radiante").document(Radiante.id!).delete()
        }
        
        return [delete]
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        guard !searchText.isEmpty else{
            radiantes = backUpradiantes
            DispatchQueue.main.async{
                self.tableView.reloadData()
            }
            return
        }
        
        radiantes = backUpradiantes.filter({ (Radiante) -> Bool in
            (Radiante.Medida?.lowercased().contains(searchText.lowercased()))!
        })
        
        DispatchQueue.main.async{
            self.tableView.reloadData()
        }
    }
    
    
    func getAlumnos(){
        //getRef.collection("alumno").getDocuments { (querySnapshot, error) in
        
        getRef.collection("Radiante").addSnapshotListener { (querySnapshot, error) in
            if let error = error{
                print(error.localizedDescription)
            }else{
                self.radiantes.removeAll()
                for document in querySnapshot!.documents{
                    let id = document.documentID
                    let values = document.data()
                    let medida = values["Medida"] as? String ?? "sin medida"
                    let radiante = Radiante(id: id, Medida: medida)
                    self.radiantes.append(radiante)
                }
                self.backUpradiantes = self.radiantes
                self.tableView.reloadData()
            }
        }
    }
    
    
    @IBAction func fueraRad(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
    
}
