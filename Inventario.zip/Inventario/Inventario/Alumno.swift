//
//  Comentario.swift
//  Inventario
//
//  Created by Fernando Pedraza Ledezma on 6/10/19.
//  Copyright © 2019 Fernando Pedraza Ledezma. All rights reserved.
//

import UIKit

class Alumno{
    
    var id: String?
    var nombre: String?
    var apellido: String?
    
    init(id: String, nombre: String, apellido: String){
        self.id = id
        self.nombre = nombre
        self.apellido = apellido
    }
    
    
}
