//
//  tablaMatPPB.swift
//  Inventario
//
//  Created by Fernando Pedraza Ledezma on 6/14/19.
//  Copyright © 2019 Fernando Pedraza Ledezma. All rights reserved.
//

import UIKit
import Firebase

class tablaMatPPB: UITableViewController, UISearchBarDelegate {
    
    var PPBlancos: [PPBlanco] = []
    var backUpPPBlancos: [PPBlanco] = []
    
    var ref: DocumentReference!
    var getRef: Firestore!
    
    
    
    @IBOutlet weak var busPPB: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getRef = Firestore.firestore()
        busPPB.delegate = self as! UISearchBarDelegate
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getAlumnos()
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return PPBlancos.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda5", for: indexPath)
        
        let PPBlanco = PPBlancos[indexPath.row]
        
        cell.textLabel!.text = "PPBlanco" //fire
        cell.detailTextLabel?.text = PPBlanco.Medida //fire
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let delete = UITableViewRowAction(style: .destructive, title: "Borrar") { (action, indexPath) in
            let PPBlanco: PPBlanco!
            PPBlanco = self.PPBlancos[indexPath.row]
            self.getRef.collection("PPBlanco").document(PPBlanco.id!).delete()
        }
        
        return [delete]
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        guard !searchText.isEmpty else{
            PPBlancos = backUpPPBlancos
            DispatchQueue.main.async{
                self.tableView.reloadData()
            }
            return
        }
        
        PPBlancos = backUpPPBlancos.filter({ (PPBlanco) -> Bool in
            (PPBlanco.Medida?.lowercased().contains(searchText.lowercased()))!
        })
        
        DispatchQueue.main.async{
            self.tableView.reloadData()
        }
    }
    
    
    func getAlumnos(){
        //getRef.collection("alumno").getDocuments { (querySnapshot, error) in
        
        getRef.collection("PPBlanco").addSnapshotListener { (querySnapshot, error) in
            if let error = error{
                print(error.localizedDescription)
            }else{
                self.PPBlancos.removeAll()
                for document in querySnapshot!.documents{
                    let id = document.documentID
                    let values = document.data()
                    let medida = values["Medida"] as? String ?? "sin medida"
                    let ppblanco = PPBlanco(id: id, Medida: medida)
                    self.PPBlancos.append(ppblanco)
                }
                self.backUpPPBlancos = self.PPBlancos
                self.tableView.reloadData()
            }
        }
    }
    
    
    @IBAction func fueraPPB(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
}

